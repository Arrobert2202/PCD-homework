import socket
import argparse
import asyncio
import hashlib
import sys
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.asyncio.server import serve
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import HandshakeCompleted, StreamDataReceived, ConnectionTerminated

class DataIntegrityValidator:
    def __init__(self):
        self._hasher = hashlib.sha256()
    def process_chunk(self, data_chunk):
        self._hasher.update(data_chunk)
    def get_final_hash(self):
        return self._hasher.hexdigest()

class QuicServerProtocol(QuicConnectionProtocol):
    def __init__(self, *args, mode, **kwargs):
        super().__init__(*args, **kwargs)
        self.mode = mode
        self.bytes_received = 0
        self.messages_received = 0
        self.validator = DataIntegrityValidator()
        self.finished = False

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived):
            if event.data == b'exit':
                self.print_results()
                self.close()
            elif event.data.endswith(b'exit'): 
                real_data = event.data[:-4]
                if real_data:
                    self.bytes_received += len(real_data)
                    self.messages_received += 1
                    self.validator.process_chunk(real_data)
                self.print_results()
                self.close()
            else:
                self.bytes_received += len(event.data)
                self.messages_received += 1
                self.validator.process_chunk(event.data)
                if self.mode == 'stop-and-wait':
                    self._quic.send_stream_data(event.stream_id, b'ACK')
                    self.transmit()
        elif isinstance(event, ConnectionTerminated):
            self.print_results()

    def print_results(self):
        if not self.finished:
            print('\n--- RESULTS ---', flush=True)
            print('Protocol: QUIC', flush=True)
            print(f'Bytes received: {self.bytes_received}, Messages received: {self.messages_received}', flush=True)
            print(f'SHA-256 Hash: {self.validator.get_final_hash()}', flush=True)
            self.finished = True

async def run_quic_server(args):
    configuration = QuicConfiguration(is_client=False)
    configuration.load_cert_chain(certfile='cert.pem', keyfile='key.pem')
    server = await serve('127.0.0.1', 12345, create_protocol=lambda *a, **kw: QuicServerProtocol(*a, mode=args.mode, **kw), configuration=configuration)
    print('Server listening on 127.0.0.1 12345 for QUIC', flush=True)
    await asyncio.Future()

def run_tcp_server(args):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('127.0.0.1', 12345))
    server_socket.listen(5)
    print('Server listening on 127.0.0.1 12345 for TCP', flush=True)

    while True:
        client_socket, _ = server_socket.accept()
        bytes_received = 0
        messages_received = 0
        validator = DataIntegrityValidator()

        while True:
            try:
                message = client_socket.recv(65535)
                if not message:
                    break
                
                bytes_received += len(message)
                messages_received += 1
                validator.process_chunk(message)
                
                if args.mode == 'stop-and-wait':
                    client_socket.sendall(b'ACK')
            except Exception:
                break
        
        print('\n--- RESULTS ---', flush=True)
        print('Protocol: TCP', flush=True)
        print(f'Bytes received: {bytes_received}, Messages received: {messages_received}', flush=True)
        print(f'SHA-256 Hash: {validator.get_final_hash()}', flush=True)
        client_socket.close()

def run_udp_server(args):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('127.0.0.1', 12345))
    server_socket.settimeout(5.0)
    print('Server listening on 127.0.0.1 12345 for UDP', flush=True)

    bytes_received = 0
    messages_received = 0
    received_seq_nums = set()
    validator = DataIntegrityValidator()

    while True:
        try:
            message, client_address = server_socket.recvfrom(65535)
            if message == b'exit':
                break

            if args.mode == 'stop-and-wait':
                parts = message.split(b':', 1)
                if len(parts) == 2:
                    try:
                        seq_num = int(parts[0].decode())
                        message_data = parts[1]
                        if seq_num not in received_seq_nums:
                            received_seq_nums.add(seq_num)
                            bytes_received += len(message_data)
                            validator.process_chunk(message_data)
                            messages_received += 1
                    except ValueError: pass
                server_socket.sendto(b'ACK', client_address)
            else:
                bytes_received += len(message)
                messages_received += 1
                validator.process_chunk(message)
        except socket.timeout:
            break

    print('\n--- RESULTS ---', flush=True)
    print('Protocol: UDP', flush=True)
    print(f'Bytes received: {bytes_received}, Messages received: {messages_received}', flush=True)
    print(f'SHA-256 Hash: {validator.get_final_hash()}', flush=True)
    server_socket.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--protocol', choices=['tcp', 'udp', 'quic'], required=True)
    parser.add_argument('--mode', choices=['streaming', 'stop-and-wait'], required=True)
    args = parser.parse_args()

    if args.protocol == 'tcp': run_tcp_server(args)
    elif args.protocol == 'udp': run_udp_server(args)
    elif args.protocol == 'quic': asyncio.run(run_quic_server(args))
