import socket
import argparse
import asyncio
import hashlib
import time
import sys
import ssl
from aioquic.asyncio.client import connect
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import HandshakeCompleted, StreamDataReceived, ConnectionTerminated

class DataIntegrityValidator:
    def __init__(self):
        self._hasher = hashlib.sha256()
    def process_chunk(self, data_chunk):
        self._hasher.update(data_chunk)
    def get_final_hash(self):
        return self._hasher.hexdigest()

class QuicClientProtocol(QuicConnectionProtocol):
    def __init__(self, *args, mode, data_size_mb, message_size, **kwargs):
        super().__init__(*args, **kwargs)
        self.mode = mode
        self.data_size_bytes = data_size_mb * 1024 * 1024
        self.message_size = message_size
        self.bytes_sent = 0
        self.messages_sent = 0
        self.start_time = None
        self.validator = DataIntegrityValidator()
        self.ack_received = asyncio.Event()
        self.handshake_completed = asyncio.Event()
        self.is_done = False

    def quic_event_received(self, event):
        if isinstance(event, HandshakeCompleted):
            self.handshake_completed.set()
            self.start_time = time.time()
            asyncio.ensure_future(self.quic_send_data())
        elif isinstance(event, StreamDataReceived):
            if event.data == b'ACK':
                self.ack_received.set()
        elif isinstance(event, ConnectionTerminated):
            self.quic_connection_lost(event.error_code)

    async def quic_send_data(self):
        await self.handshake_completed.wait()
        stream_id = 0
        chunk_base = b'0' * self.message_size
        
        while self.bytes_sent < self.data_size_bytes:
            send_len = min(self.message_size, self.data_size_bytes - self.bytes_sent)
            current_chunk = chunk_base[:send_len]

            self._quic.send_stream_data(stream_id, current_chunk, end_stream=False)
            self.validator.process_chunk(current_chunk)
            self.bytes_sent += send_len
            self.messages_sent += 1

            if self.mode == 'stop-and-wait':
                self.transmit()
                await self.ack_received.wait()
                self.ack_received.clear()
            else:
                if self.messages_sent % 100 == 0:
                    self.transmit()
                    await asyncio.sleep(0.001)

        self._quic.send_stream_data(stream_id, b'exit', end_stream=True)
        self.transmit()

    def quic_connection_lost(self, exc):
        self.is_done = True 
        elapsed = time.time() - self.start_time if self.start_time else 0
        print(f'Total transmission time: {elapsed:.3f} seconds')
        print(f'SHA-256 Hash: {self.validator.get_final_hash()}')
        print(f'Bytes sent: {self.bytes_sent}')
        print(f'Messages sent: {self.messages_sent}')
        super().connection_lost(exc)

async def run_quic_client(args):
    configuration = QuicConfiguration(is_client=True)
    configuration.verify_mode = ssl.CERT_NONE
    
    try:
        async with connect(
            '127.0.0.1', 12345, configuration=configuration,
            create_protocol=lambda *a, **kw: QuicClientProtocol(*a, mode=args.mode, data_size_mb=args.data_size, message_size=args.message_size, **kw)
        ) as protocol:
            while not getattr(protocol, 'is_done', False):
                await asyncio.sleep(0.1)
            await asyncio.sleep(0.5) 
    except Exception as e:
        sys.exit(1)

def run_tcp_client(args):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 12345))
    
    validator = DataIntegrityValidator()
    data_size_bytes = args.data_size * 1024 * 1024
    bytes_sent = 0
    messages_sent = 0
    chunk = b'0' * args.message_size
    
    start_time = time.time()
    while bytes_sent < data_size_bytes:
        send_len = min(args.message_size, data_size_bytes - bytes_sent)
        current_chunk = chunk[:send_len]
        try:
            client_socket.sendall(current_chunk)
            validator.process_chunk(current_chunk)
            bytes_sent += send_len
            messages_sent += 1
            if args.mode == 'stop-and-wait':
                if client_socket.recv(3) != b'ACK': break
        except Exception:
            break
            
    end_time = time.time()
    client_socket.close()
    
    print(f'Total transmission time: {end_time - start_time:.3f} seconds')
    print(f'SHA-256 Hash: {validator.get_final_hash()}')
    print(f'Bytes sent: {bytes_sent}')
    print(f'Messages sent: {messages_sent}')

def run_udp_client(args):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.settimeout(5.0)
    
    validator = DataIntegrityValidator()
    data_size_bytes = args.data_size * 1024 * 1024
    bytes_sent = 0
    messages_sent = 0
    seq_num = 0
    chunk = b'0' * args.message_size
    
    start_time = time.time()
    while bytes_sent < data_size_bytes:
        send_len = min(args.message_size, data_size_bytes - bytes_sent)
        current_chunk = chunk[:send_len]
        try:
            if args.mode == 'stop-and-wait':
                message = f'{seq_num}:'.encode() + current_chunk
                client_socket.sendto(message, ('127.0.0.1', 12345))
                try:
                    ack, _ = client_socket.recvfrom(3)
                    if ack == b'ACK':
                        validator.process_chunk(current_chunk)
                        bytes_sent += send_len
                        messages_sent += 1
                        seq_num += 1
                    else: break
                except socket.timeout:
                    continue
            else:
                client_socket.sendto(current_chunk, ('127.0.0.1', 12345))
                validator.process_chunk(current_chunk)
                bytes_sent += send_len
                messages_sent += 1
        except Exception:
            break
            
    try: client_socket.sendto(b'exit', ('127.0.0.1', 12345))
    except: pass
        
    end_time = time.time()
    client_socket.close()
    
    print(f'Total transmission time: {end_time - start_time:.3f} seconds')
    print(f'SHA-256 Hash: {validator.get_final_hash()}')
    print(f'Bytes sent: {bytes_sent}')
    print(f'Messages sent: {messages_sent}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--protocol', choices=['tcp', 'udp', 'quic'], required=True)
    parser.add_argument('--mode', choices=['streaming', 'stop-and-wait'], required=True)
    parser.add_argument('--data_size', type=int, required=True)
    parser.add_argument('--message_size', type=int, required=True)
    args = parser.parse_args()

    if args.protocol == 'tcp': run_tcp_client(args)
    elif args.protocol == 'udp': run_udp_client(args)
    elif args.protocol == 'quic': asyncio.run(run_quic_client(args))